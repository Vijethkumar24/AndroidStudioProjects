package aj.cs.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HomePageActivity extends AppCompatActivity {
    EditText firstNumberEditText,SecondNumberEditText;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        firstNumberEditText=(EditText) findViewById(R.id.firstNumber);
        SecondNumberEditText=(EditText) findViewById(R.id.secondNumber);
        resultText=(TextView) findViewById(R.id.result);

    }
    public void onClickAdd(View v)
    {
        Double fNumber=Double.parseDouble(firstNumberEditText.getText().toString());
        Double sNumber=Double.parseDouble(SecondNumberEditText.getText().toString());
        Double res=fNumber+sNumber;
        resultText.setText(res.toString());
    }
    public void onClickSub(View v)
    {
        Double fNumber=Double.parseDouble(firstNumberEditText.getText().toString());
        Double sNumber=Double.parseDouble(SecondNumberEditText.getText().toString());
        Double res=fNumber-sNumber;
        resultText.setText(res.toString());
    }
    public void onClickMul(View v)
    {
        Double fNumber=Double.parseDouble(firstNumberEditText.getText().toString());
        Double sNumber=Double.parseDouble(SecondNumberEditText.getText().toString());
        Double res=fNumber*sNumber;
        resultText.setText(res.toString());
    }
    public void onClickDiv(View v)
    {
        Double fNumber=Double.parseDouble(firstNumberEditText.getText().toString());
        Double sNumber=Double.parseDouble(SecondNumberEditText.getText().toString());
        if(sNumber.intValue()==0)
        {
            resultText.setText("Divide By Zero Error!!");
        }
        else {
            Double res = fNumber / sNumber;
            resultText.setText(res.toString());
        };
    }

}