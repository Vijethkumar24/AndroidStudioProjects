package com.example.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button convertBtn;
    EditText amountField;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        convertBtn=(Button) findViewById(R.id.button);
        amountField=(EditText)findViewById(R.id.editTextNumber2);
    }
    public void onClickConvert(View v)
    {
        Double poundAmount=new Double(Double.parseDouble(amountField.getText().toString()));
        Double result=poundAmount*0.75;
        Toast.makeText(this, String.format("%.2f",result)+"€", Toast.LENGTH_LONG).show();
    }
}